$.fn.greenify = function() {
	this.css('color', '#BADA55');
	return this;
}