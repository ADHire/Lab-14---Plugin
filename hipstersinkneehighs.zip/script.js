$(document).ready(function() {
	$('a').greenify().fadeOut(1000).delay(400).fadeIn(1000);
});